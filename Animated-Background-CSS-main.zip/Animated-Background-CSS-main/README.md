
# Animated Background | HTML, CSS & Javascript 

Hey,
In this video, I created an awesome and unique Animated Background with Cool Effects that will help you to make Single Page Websites / Landing Pages / Home Pages and more. This HTML, CSS & Javascript Website Tutorial will really help you in web development.
Watch Full Tutorial and Your Comments really means a lot! ❤



[🔴 Youtube Tutorial Video](https://youtu.be/7Cb19XSJBXs)

[🔵 Live Project URL](https://teenageprogrammer.github.io/Animated-Background-CSS/)

If you want any answers related this project, You can Join My New Discord Server!
Welcome!

[🟣 Join Discord Server](https://discord.gg/G5zDJbVpMx)




## Screenshot

![App Screenshot](https://i.ibb.co/sJyswdt/Thumbnail1.png)


## 🚀 About Me
Teenage Programmer - Developing unique projects and trying to make web development learning easy to freshy users in this field. Fast track your development career with me. Hope you'll love my creativity.


[SUBSCRIBE YOUTUBE](https://www.youtube.com/channel/UCHpW7UyMQf0SXpdO0obb1ig)


![App Screenshot](https://yt3.ggpht.com/oGB27ubPR1zD7eqatjSUZRnMqdr1WAV6g3wC39d-G0hFTIrkzq0FK5_Z9sgAGQsTHEzOOgSw=s88-c-k-c0x00ffffff-no-rj)
